<?php
// mysqli_connect("hostname","user database","password","nama")
$koneksi= mysqli_connect("localhost","root","","dbobat") or die("Tidak bisa terhubungan ke database");


